Please read: [Unethical behavior by Manning, the publisher of Big Data](http://big-data-manning.blogspot.com/2015/09/unethical-behavior-by-manning-publisher.html)

The source code for the batch, serving, and speed layers of SuperWebAnalytics.com as described in [Big Data: Principles and best practices of scalable realtime data systems](http://www.amazon.com/dp/1617290343)